######################################################
## code to debug the "access denied" issue
######################################################
import requests
# inspect website to find particular item code
url = 'https://edh-www.adw.uni-heidelberg.de/edh/inschrift/HD000042&lang=en'

badresponse = requests.get(url) #access the website with requests library
print (badresponse.text)
print(badresponse.status_code)
print ("-------------")

# spoofing user agent
user_agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36'
goodresponse = requests.get(url, headers={"User-agent":user_agent}) #access the website with requests library
print(goodresponse.status_code)

######################################################
## Code to understand what's bad with the html
######################################################

from bs4 import BeautifulSoup
import requests

# inspect website to find particular item code
url = 'https://edh-www.adw.uni-heidelberg.de/edh/inschrift/HD000042&lang=en'

user_agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36'
response = requests.get(url, headers={"User-agent":user_agent}) #access the website with requests library

#parse HTML and save to BeautifulSoup object
bigsoup = BeautifulSoup(response.text, "html.parser")
## the html parser give a wrong html (check for</body></html> in wrong position)
print ("--------------------------------------start------------------------------------")
print(bigsoup)
print ("--------------------------------------end------------------------------------")


######################################################
## the solution
######################################################

from bs4 import BeautifulSoup
import requests

# inspect website to find particular item code
url = 'https://edh-www.adw.uni-heidelberg.de/edh/inschrift/HD000042&lang=en'

user_agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36'
response = requests.get(url, headers={"User-agent":user_agent}) #access the website with requests library

#parse HTML and save to BeautifulSoup object
bigsoup = BeautifulSoup(response.text, "html.parser")

dates = bigsoup.find('td', text='Chronological data:').find_next('td')
print(dates.text)
